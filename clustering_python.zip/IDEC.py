from __future__ import print_function, division
import argparse
import numpy as np
from sklearn.cluster import KMeans
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from eval_clustering import tsne


class IDEC(nn.Module):

    def __init__(self, X,
                 model, optim,
                 n_clusters,
                 settings,
                 alpha=1,
                 pretrain_path='../models/ae.pkl'):
        super(IDEC, self).__init__()
        self.alpha = 1.0
        self.pretrain_path = pretrain_path
        self.X = X
        self.n_z = settings["rho_output_dim"]
        self.n_iters = settings["iterations"]
        self.pretrain_n_iters = settings["pretrain_iterations"]
        self.batch_size = settings["batch_size"]
        self.n_clusters = n_clusters
        self.ae = model
        self.optim = optim
        # cluster layer
        self.cluster_layer = Parameter(torch.Tensor(n_clusters, self.n_z))
        torch.nn.init.xavier_normal_(self.cluster_layer.data)
     

    def pretrain(self, evaluation, path=''):
        if path == '':
            for iter in range(1, self.pretrain_n_iters + 1):
                indices = np.random.choice(range(len(self.X)), size=self.batch_size)

                output, loss = self.pretrain_batch(self.X[indices, :])
                evaluation.write_episode_data(iter, {"loss": loss, "reassigned" : 0})
                if iter % 100 == 0:
                    print(iter, "pretrain loss: ", loss)
                    torch.save(self.ae.state_dict(), self.pretrain_path)
        # load pretrain weights
        self.ae.load_state_dict(torch.load(self.pretrain_path))
        print('load pretrained ae from', path)


    def pretrain_batch(self, inputs):
        self.optim.zero_grad()
        outputs, _ = self.ae.forward(inputs)
        inputs_wo_nans = np.copy(inputs)
        inputs_wo_nans[inputs_wo_nans != inputs_wo_nans] = 0  # replace nans with zeros for reconstruction
        rec = torch.cat([torch.Tensor(i).cuda(0).view(1, -1) for i in inputs_wo_nans], dim=0)
        #loss = self.loss_function(outputs, rec)
        loss = F.mse_loss(outputs, rec)
        loss.backward()
        self.optim.step()
        return outputs, loss.cpu().item()


    def forward(self, x):
        x_bar, z = self.ae(x)
        # cluster
        q = 1.0 / (1.0 + torch.sum(
            torch.pow(z.unsqueeze(1) - self.cluster_layer, 2), 2) / self.alpha)
        q = q.pow((self.alpha + 1.0) / 2.0)
        q = (q.t() / torch.sum(q, 1)).t()
        return x_bar, q, z

    def target_distribution(self, q):
        weight = q**2 / q.sum(0)
        return (weight.t() / weight.sum(1)).t()


    def train_batch(self, inputs, p, gamma=0.1):
        x_bar, q, _ = self.forward(inputs)

        inputs_wo_nans = np.copy(inputs)
        inputs_wo_nans[inputs_wo_nans != inputs_wo_nans] = 0  # replace nans with zeros for reconstruction
        rec = torch.cat([torch.Tensor(i).cuda(0).view(1, -1) for i in inputs_wo_nans], dim=0)
        reconstr_loss = F.mse_loss(x_bar, rec)

        kl_loss = F.kl_div(q.log(), p)
        loss = gamma * kl_loss + reconstr_loss

        self.optim.zero_grad()
        loss.backward()
        self.optim.step()

        return loss.item()

    def train(self, evaluation, model_path):

        loss = 0.0
        self.pretrain(evaluation)

        # cluster parameter initiate
        x_bar, hidden = self.ae.forward(self.X)

        kmeans = KMeans(n_clusters=self.n_clusters, n_init=20)
        y_pred = kmeans.fit_predict(hidden.data.cpu().numpy())

        hidden = None
        x_bar = None

        y_pred_last = y_pred
        self.cluster_layer.data = torch.tensor(kmeans.cluster_centers_).cuda()
        self.ae.train()

        for iter in range(0, self.n_iters + 1):
            indices = np.random.choice(range(len(self.X)), size=self.batch_size)
            if iter % 100 == 0 or iter >= self.n_iters:

                _, tmp_q, latent = self.forward(self.X)

                # update target distribution p
                tmp_q = tmp_q.data
                print("Q size", tmp_q.size())
                p = self.target_distribution(tmp_q)
                cluster = torch.argmax(tmp_q, dim = 1).cpu().numpy()


                # evaluate clustering performance
                y_pred = tmp_q.cpu().numpy().argmax(1)
                delta_label = np.sum(y_pred != y_pred_last).astype(
                    np.float32) / y_pred.shape[0]
                y_pred_last = y_pred

                if iter > 0 and delta_label < 1e-4:
                    print('delta_label {:.4f}'.format(delta_label), '< tol')
                    print('Reached tolerance threshold. Stopping training.')
                    break
                print(iter, "train loss: ", loss)

            loss = self.train_batch(self.X[indices, :],  p[indices])
            evaluation.write_episode_data(self.pretrain_n_iters  + iter, {"loss": loss, "reassigned" :delta_label})


            if iter % 500 == 0:
                tsne(latent.detach().cpu().numpy(), cluster, model_path, self.n_clusters, self.cluster_layer.data.detach().cpu().numpy())
        return self.ae, cluster
        
if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description='train',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--n_clusters', default=7, type=int)
    parser.add_argument('--batch_size', default=256, type=int)
    parser.add_argument('--n_z', default=10, type=int)
    parser.add_argument('--dataset', type=str, default='mnist')
    parser.add_argument('--pretrain_path', type=str, default='data/ae_mnist')
    parser.add_argument(
        '--gamma',
        default=0.1,
        type=float,
        help='coefficient of clustering loss')
    parser.add_argument('--update_interval', default=1, type=int)
    parser.add_argument('--tol', default=0.001, type=float)
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    print("use cuda: {}".format(args.cuda))
    device = torch.device("cuda" if args.cuda else "cpu")

    if args.dataset == 'mnist':
        args.pretrain_path = 'data/ae_mnist.pkl'
        args.n_clusters = 10
        args.n_input = 784
        dataset = MnistDataset()
    print(args)
    train_idec()
