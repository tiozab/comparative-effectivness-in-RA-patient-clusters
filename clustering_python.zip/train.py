import torch.optim as optim
import torch
import pandas as pd
import numpy as np
from network import Net
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from tensorboard_evaluation import Evaluation
from IDEC import IDEC
import time
import json
import string
import random
import matplotlib.pyplot as plt
import os

np.random.seed(123)

def _run_name(model_type):
    return time.strftime("output_%b_%d_%H%M%S_") + ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(5)) +  "_%s" %model_type


if __name__ == '__main__':

    plot_every  = 100
    batch_size = 64
    projector = True

    # for IDEC
    n_cluster = 6

    file = "../data/beforev4.csv"    
    data = pd.read_csv(file, encoding = "ISO-8859-1")
    data = data.replace(".", np.NaN)


    features = pd.read_csv("../data/v4_feature_varlist.csv").values.flatten()
    features = [f for f in features if "delta" not in f]

    # get time deltas if available
    delta_features = []
    for f in features:
        for c in data.columns:
            if "delta_%s" %f in c:
                delta_features.append(f)
                break

    # count number of inputs per features
    features_n = []   
    for f in features:
        if f in delta_features:
                features_n.append(2)
        else:
            features_n.append(1)   

    # scale features (z-scaling)
    for f in features + ["delta_%s" %df for df in delta_features]:
        tmp = data[f].values.astype("float")
        data[[f]] =  (tmp - np.nanmean(tmp, axis=0))/np.nanstd(tmp, axis=0) 

    # build dataframe
    X = []
    for index, row in data.iterrows():
        x = []

        for f in features:
            x.append(float(row[f]))
            if f in delta_features:
                x.append(float(row["delta_%s" %f]))
        x = np.array(x)
        X.append(x)
    X = np.array(X)

    print(np.array(features_n).sum())
    assert(X.shape[1] == np.array(features_n).sum())
    

    use_cuda = True    
    settings = {
                "phi_hidden_dim" : [64] * len(features_n), 
                "phi_output_dim" : 64, 
                "rho_hidden_dim" : 1024, 
                "rho_output_dim" : 10,
                "projector" : projector,
                "batch_size" : batch_size,
                "iterations" : 75000,
                "pretrain_iterations" : 50000
                }

    f_name = "clustering"

    store_dir = os.path.join("./outputs", f_name + _run_name("clustering"))
    os.makedirs(store_dir)

    with open(os.path.join(store_dir, "settings.json"), 'w') as outfile:
        json.dump(settings, outfile, indent=2)

    # define model
    model = Net(
            feature_input_dim=features_n,
            encoder_hidden_dim=settings["phi_hidden_dim"] * len(features_n), 
            encoder_output_dim=settings["phi_output_dim"], 
            rho_hidden_dim=settings["rho_hidden_dim"], 
            rho_output_dim=settings["rho_output_dim"],
            projector= settings["projector"],
            features=features,
            use_cuda=use_cuda)


    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    evaluation = Evaluation(os.path.join(store_dir, "tensorboard_evaluation"), fold=0, name="rheuma", stats=[ "loss", "reassigned"])

    idec = IDEC(X, model, optimizer, n_cluster, settings)

    model, cluster = idec.train(evaluation, store_dir)

    np.save(os.path.join(store_dir, "cluster.npy"), cluster)
    df_cluster = pd.DataFrame(columns=["Cluster"], data=cluster)
    df_cluster.to_csv("cluster.csv")

    # Save model
    torch.save(model.state_dict(), os.path.join(store_dir, "model.pt"))  
    
