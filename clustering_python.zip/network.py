"""
Anynets for Clustering
"""

import torch
import torch.nn as nn
from torch.nn import init
import numpy as np
import time
import torch.nn as nn
from utils import global_add_pool
import torch.multiprocessing as mp

class EncoderProjector(nn.Module):
    def __init__(self, input_dim, output_dim, activation=None):
        super(EncoderProjector, self).__init__()
        self.fc_in = nn.Linear(input_dim, output_dim)
        self.activation = activation

    def forward(self, x):
        x = nn.functional.relu(self.fc_in(x))
        return x

class Encoder(nn.Module):
    """
    Feature Encoder Network (projects features to a higher dimensional vector)
    """
    def __init__(self, input_dim, hidden_dim=None, output_dim=None):
        super(Encoder, self).__init__()
        self.hidden_dim = hidden_dim
        if self.hidden_dim:
            self.rho_in = nn.Linear(input_dim, hidden_dim)
            self.rho_out = nn.Linear(hidden_dim, output_dim)
        else:
            self.rho_in = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = nn.functional.relu(self.rho_in(x))
        if self.hidden_dim:
            x = nn.functional.relu(self.rho_out(x))
        return x

class Decoder(nn.Module):
    """
    Decoder Network (reconstructs features from combined latent vector)
    """
    def __init__(self, input_dim, hidden_dim=None, output_dim=None):
        super(Decoder, self).__init__()
        self.hidden_dim = hidden_dim
        self.rho_in = nn.Linear(input_dim, hidden_dim)
        self.rho_out = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = nn.functional.relu(self.rho_in(x))
        x = self.rho_out(x)
        return x


class Net(nn.Module):

    def __init__(self, feature_input_dim, encoder_hidden_dim, encoder_output_dim, rho_hidden_dim, rho_output_dim, projector, features, use_cuda=False, gpu=0): 
        super(Net, self).__init__()

	# different features (for each data_type, we create a phi and Q network)
        self.features = features            
        self.encoder_output_dim = encoder_output_dim
        self.feature_input_dim = feature_input_dim
        self.projector = projector
        self.rho_input_dim = encoder_output_dim 
        self.rho_output_dim = rho_output_dim

        # create encoder networks
        self.encoder = {}
        for i, type in enumerate(features):
            self.encoder[type] = Encoder(feature_input_dim[i], encoder_hidden_dim[i], encoder_output_dim)
            if use_cuda:
                self.encoder[type] = self.encoder[type].cuda(gpu)

        # create projector network to project all encoder vectors to the same latent space (see AdaptiveNet)
        if self.projector:
            self.encoder_pro = EncoderProjector(encoder_output_dim, encoder_output_dim)
            if use_cuda:
                self.encoder_pro = self.encoder_pro.cuda(gpu)
       
        # create decoder networks
        self.decoder = {}
        for i, type in enumerate(features):
            self.decoder[type] = Decoder(rho_hidden_dim, encoder_hidden_dim[i], feature_input_dim[i])
            if use_cuda:
                self.decoder[type] = self.decoder[type].cuda(gpu)

        # create rho layers
        self.rho_in = nn.Linear(self.rho_input_dim , rho_hidden_dim)
        self.rho_in2 = nn.Linear(rho_hidden_dim , rho_hidden_dim)
        self.rho_latent = nn.Linear(rho_hidden_dim, rho_output_dim)
        self.rho_out = nn.Linear(rho_output_dim, rho_hidden_dim)
        self.rho_out2 = nn.Linear(rho_hidden_dim, rho_hidden_dim)

        if use_cuda:
            self.rho_in = self.rho_in.cuda(gpu)
            self.rho_in2 = self.rho_in2.cuda(gpu)
            self.rho_latent = self.rho_latent.cuda(gpu)
            self.rho_out = self.rho_out.cuda(gpu)
            self.rho_out2 = self.rho_out2.cuda(gpu)

        self.use_cuda = use_cuda
        self.gpu = gpu

    def init_hidden(self, batch_size):
        return torch.zeros(1, batch_size, self.rho_input_dim)

    def forward(self, states): 

        batch_size = len(states) 
        non_zero_ids = {}      # some states could contain only missing values (nans), so we have to save non_zero state-ids for the scatter operation
        batch_index = dict()   # saves the state id the feature belongs to. We need this to perform global_add_pool (sums up all features in a state for the whole batch)
        features = dict()      # saves input per feature type

        for type in self.features:
            batch_index[type] = []
            features[type] = []
            non_zero_ids[type] = []

        j = 0
        # iterate over all states and seperating features
        #print("whole state", states[0])
        for i, s in enumerate(states):
            found = False
            start = 0
            for k, type in enumerate(self.features):
                state = s[start: start+int(self.feature_input_dim[k])].reshape(1, self.feature_input_dim[k])

                # check if feature input is nan, add only features that are not nan, save corresponding ids and batch indexes to compute the sum later
                if len(state) > 0 and not np.isnan(state).any():
                    found = True
                    features[type].extend(state)
                    batch_index[type].extend(np.repeat(j, len(state))) 
                    non_zero_ids[type].append(np.repeat(i, self.rho_input_dim)) 

                start += int(self.feature_input_dim[k])
            
            if found:
                j += 1

        # compute encoded feature representations for all features and concatenate them
        tmp = []
        tmp_batch_index = []
        for index, type in enumerate(self.features):
            batch_index[type] = torch.LongTensor(batch_index[type])
            non_zero_ids[type] = torch.LongTensor(np.array(non_zero_ids[type]))

            if self.use_cuda:
                batch_index[type] = batch_index[type].cuda(self.gpu)
                non_zero_ids[type] = non_zero_ids[type].cuda(self.gpu)

            features_var = torch.Tensor(features[type])
            if len(features_var) > 0:
                if self.use_cuda:
                    features_var = features_var.cuda(self.gpu)
                    x_type = self.encoder[type].forward(features_var)
                    if self.projector:
                        x_type = self.encoder_pro.forward(x_type)
                    tmp.append(x_type)
                    tmp_batch_index.append(batch_index[type])
        
        x = torch.cat(tmp, dim=0) 
        x_batch_index = torch.cat(tmp_batch_index, dim=0)

        # sum all features for one state
        tmp = torch.zeros((1, self.rho_input_dim))
        if self.use_cuda:
            tmp = tmp.cuda(self.gpu)
        
        x_all = global_add_pool(x, x_batch_index, size=x_batch_index.max() + 1) if len(x) > 0 else tmp

        # compute rho representation (out_latent is the latent vector we will use for clustering)
        out = nn.functional.relu(self.rho_in(x_all))
        out = nn.functional.relu(self.rho_in2(out))
        out_vector= self.rho_latent(out)
        out_latent = nn.functional.relu(self.rho_out(out_vector))
        out_latent = nn.functional.relu(self.rho_out2(out_latent))


        # compute reconstructions from latent representations
        rec = []
        for k, type in enumerate(self.features):
            out = out_latent.gather(0, batch_index[type].reshape(-1, 1).repeat(1, out_latent.size()[1]))
            rec_type = self.decoder[type].forward(out)

            # fill in the states in the batch with no other cars    
            outputs = torch.zeros((batch_size, self.feature_input_dim[k]))
            if self.use_cuda:
                outputs = outputs.cuda(self.gpu)
          
            if len(non_zero_ids[type]) > 0:
                outputs =  outputs.scatter_(0, non_zero_ids[type][:, :self.feature_input_dim[k]], rec_type)
            rec.append(outputs)

        rec = torch.cat(rec, dim=1)

        return rec, out_vector



