import torch.optim as optim
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from network import Net
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import os
import time
import json
import string
import random
import matplotlib.pyplot as plt
from MulticoreTSNE import MulticoreTSNE as TSNE
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

np.random.seed(123)

def load_latent_vectors(X, model_path, features, features_n, settings, use_cuda):
    # load network from model_path
    model = Net(
            feature_input_dim=features_n,
            encoder_hidden_dim=settings["phi_hidden_dim"] * len(features_n), 
            encoder_output_dim=settings["phi_output_dim"], 
            rho_hidden_dim=settings["rho_hidden_dim"], 
            rho_output_dim=settings["rho_output_dim"],
            projector= settings["projector"],
            features=features,
            use_cuda=use_cuda)

    model.load_state_dict(torch.load(os.path.join(model_path, "model.pt"), map_location=lambda storage, location: storage))

    # read latent vectors
    latent_vectors = []
    for ind in range(0, len(X), 10000):
        print(ind)
        _, tmp = model.forward(X[ind:ind+10000])
        tmp = tmp.detach().cpu().numpy()
        latent_vectors.append(tmp)

    latent_vectors = np.concatenate(latent_vectors, axis=0)
    return latent_vectors


def cluster(latent_vectors, n_clusters):
    # K-Means
    kmeans = KMeans(n_clusters=n_clusters)
    cluster = kmeans.fit_predict(latent_vectors)
    return cluster
    

def tsne(latent_vectors, cluster, model_path, n_clusters, centers=None):
    df = pd.DataFrame(columns=["ids", "cluster"])
    df["vectors"] = range(len(cluster))
    df["clusters"] = cluster


    df = df.groupby('clusters', group_keys=False).apply(pd.DataFrame.sample, n=200, replace=True)

    tsne =  TSNE(n_components=2, n_jobs=4)  
    # TSNE
    if centers is not None:
        all_vectors = np.concatenate([latent_vectors, centers], axis=0)
        all_tsne_vectors = tsne.fit_transform(all_vectors)
        tsne_vectors = all_tsne_vectors[:-n_clusters, :]
        centers = all_tsne_vectors[-n_clusters:, :]
        plt.scatter(tsne_vectors[:,0],tsne_vectors[:,1], c = cluster)
        plt.scatter(centers[:,0],centers[:,1], c ="black", s=8)
    else:
        tsne_vectors = tsne.fit_transform(latent_vectors)
        plt.scatter(tsne_vectors[:,0],tsne_vectors[:,1], c = cluster)


    plt.title('K-Means, TSNE, n_clusters = %s'%n_clusters)
    plt.savefig(os.path.join(model_path, '%s_clusters_tsne.png'%(n_clusters)))
    plt.clf()
    plt.close()


def pca_tsne(latent_vectors, cluster, model_path, n_clusters):
    # PCA
    print("PCA")
    pca = PCA(n_components=2)
    pca_vectors = pca.fit_transform(latent_vectors)
    plt.scatter(pca_vectors[:,0],pca_vectors[:,1], c = cluster)
    plt.title('K-Means, PCA, n_clusters = %s'%n_clusters)
    plt.savefig(os.path.join(model_path  , '%s_clusters_pca.png'%(n_clusters)))
    plt.clf()
    plt.close()

    print("TSNE")
    # TSNE
    tsne =  TSNE(n_components=2, n_jobs=4)
    tsne_vectors = tsne.fit_transform(latent_vectors)

    plt.scatter(tsne_vectors[:,0],tsne_vectors[:,1], c = cluster)
    plt.title('K-Means, TSNE, n_clusters = %s'%n_clusters)
    plt.savefig(os.path.join(model_path, '%s_clusters_tsne.png'%(n_clusters)))
    plt.clf()
    plt.close()
    
   

